/* 
 * File:   prglib.h
 * Author: msobral
 *
 * Created on 10 de Agosto de 2016, 15:08
 */

#ifndef PRGLIB_H
#define	PRGLIB_H

#include "libs/lista.h"
#include "libs/fila.h"
#include "libs/pilha.h"
#include "libs/hash.h"
#include "libs/arvore.h"

#endif	/* PRGLIB_H */
