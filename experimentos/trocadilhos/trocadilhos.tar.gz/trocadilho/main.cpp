#include <iostream>
#include <string>
#include <fstream>
#include "prglib.h"

using namespace prglib;
using namespace std;

int main(int argc, char * argv[]) {
    string entrada, nada;
    lista<string> trocadilhos;
   
    ifstream arquivo(argv[1]);
    while (getline(arquivo, entrada)){
        trocadilhos.anexa(entrada);
    }

    trocadilhos.embaralha();
    trocadilhos.inicia();
   
    while (! trocadilhos.fim()){
        cout << trocadilhos.proximo() << endl;
        getline(cin, nada);
    }
    return 0;
}
